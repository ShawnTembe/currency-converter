export const environment = {
    production: true,
    baseAPIUrl: 'http://localhost:4200',
    exchangeRatesAPIUrl: 'https://api.ratesapi.io/api/latest',
};
